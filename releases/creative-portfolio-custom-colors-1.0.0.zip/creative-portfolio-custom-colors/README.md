# Creative Portfolio Custom Colors

This plugin adds custom colors functionality into the Creative Portfolio WordPress Theme. See the Creative Market [1] product page for more information.

[1] https://creativemarket.com/professionalthemes/185375-Creative-Portfolio-WordPress-Theme
